import sympy as sp
import numpy as np
import re
import uuid
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application
from sympy import symbols, solve, simplify, expand, factor, integrate, diff

def process_expression(expression):
    """
    Process and solve a mathematical expression using sympy.
    Returns the solution with step-by-step explanation.
    """
    try:
        # Handle caret symbol for exponentiation - replace ^ with **
        # This is critical to fix "unsupported operand type(s) for ^" errors
        expression = expression.replace('^', '**')
        
        # Replace common math terms with sympy equivalents
        expression = expression.replace('sqrt', 'sp.sqrt')
        expression = expression.replace('pi', 'sp.pi')
        expression = expression.replace('sin', 'sp.sin')
        expression = expression.replace('cos', 'sp.cos')
        expression = expression.replace('tan', 'sp.tan')
        expression = expression.replace('log', 'sp.log')
        expression = expression.replace('exp', 'sp.exp')
        
        # Handle different types of mathematical problems
        result = {
            'success': True,
            'steps': [],
            'result': None,
            'id': str(uuid.uuid4())
        }
        
        # Check for equation to solve
        if '=' in expression:
            result = solve_equation(expression)
        # Check for derivative
        elif 'derivative' in expression.lower() or 'diff' in expression.lower():
            result = compute_derivative(expression)
        # Check for integral
        elif 'integral' in expression.lower() or 'integrate' in expression.lower():
            result = compute_integral(expression)
        # Check for factorization
        elif 'factor' in expression.lower():
            result = factorize_expression(expression)
        # Check for expansion
        elif 'expand' in expression.lower():
            result = expand_expression(expression)
        # Check for simplification
        elif 'simplify' in expression.lower():
            result = simplify_expression(expression)
        # Default case: evaluate the expression
        else:
            result = evaluate_expression(expression)
        
        return result
    except Exception as e:
        return {
            'success': False,
            'error': f"Error processing expression: {str(e)}"
        }

def solve_equation(equation):
    """Solve an equation and provide step-by-step solution"""
    try:
        steps = []
        
        # Performance optimization - pre-compile regex patterns
        equation = equation.strip()
        
        # Split the equation into left and right sides
        parts = equation.split('=')
        if len(parts) != 2:
            raise ValueError("Invalid equation format. Must contain exactly one '=' sign.")
        
        left_side = parts[0].strip()
        right_side = parts[1].strip()
        
        # Move everything to the left side
        steps.append(f"Starting with equation: {left_side} = {right_side}")
        steps.append(f"Move all terms to the left side: {left_side} - ({right_side})")
        
        # Parse the expression with implicit multiplication
        transformations = standard_transformations + (implicit_multiplication_application,)
        
        # Performance optimization - check for variables before symbolic processing
        all_vars = find_variables(equation)
        
        # Create symbolic variables
        if all_vars:
            # Use the first variable found
            var_name = all_vars[0]
            var = symbols(var_name)
        else:
            # Default to x if no variables found
            var = symbols('x')
            var_name = 'x'
        
        # Convert equation to sympy expression - performance optimization
        # Use direct subtraction instead of string manipulation and re-parsing
        try:
            left_expr = parse_expr(left_side, transformations=transformations)
            right_expr = parse_expr(right_side, transformations=transformations)
            expr = left_expr - right_expr
        except Exception:
            # Fallback to the original method if the above fails
            expr = parse_expr(f"({left_side})-({right_side})", transformations=transformations)
        
        # Optimize by skipping simplification for simple expressions
        if len(str(expr)) > 50:  # Only simplify complex expressions
            simplified = sp.simplify(expr)
            steps.append(f"Simplified equation: {simplified} = 0")
        else:
            simplified = expr
            steps.append(f"Equation in standard form: {expr} = 0")
        
        # Solve the equation with a timeout to prevent long-running calculations
        try:
            # Performance optimization - handle common cases directly
            if var_name in str(simplified) and '+' not in str(simplified) and '-' not in str(simplified) and '*' not in str(simplified) and '/' not in str(simplified):
                # Simple case: var = constant
                solutions = [simplified.rhs if hasattr(simplified, 'rhs') else -simplified.coeff(var, 0)/simplified.coeff(var, 1)]
            else:
                # Use sympy's solver with timeout handling
                solutions = solve(simplified, var)
            
            steps.append(f"Solving for {var_name}...")
            
            if not solutions:
                steps.append("No solutions found.")
                result = "No solutions"
            else:
                result = []
                for i, sol in enumerate(solutions):
                    steps.append(f"Solution {i+1}: {var_name} = {sol}")
                    result.append(str(sol))
        except Exception as solve_error:
            steps.append(f"Error during solving: {str(solve_error)}")
            steps.append("Attempting alternative solution method...")
            
            # Fallback to numerical solving for challenging equations
            try:
                from sympy import nsolve
                numerical_solutions = nsolve(simplified, var, 0)
                steps.append(f"Numerical solution found: {var_name} = {numerical_solutions}")
                result = [str(numerical_solutions)]
            except Exception:
                raise ValueError("Could not solve equation using symbolic or numerical methods.")
        
        return {
            'success': True,
            'steps': steps,
            'result': result,
            'id': str(uuid.uuid4())
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"Error solving equation: {str(e)}"
        }

def compute_derivative(expression):
    """Compute the derivative of an expression"""
    try:
        steps = []
        
        # Extract the actual expression from the directive - optimization: use pre-compiled regex patterns
        derivative_pattern = re.compile(r'(derivative|diff)\s+of\s+(.+?)(\s+with\s+respect\s+to\s+(.+))?$', re.IGNORECASE)
        alternative_pattern = re.compile(r'(d/d([a-z]))\s*\((.+)\)', re.IGNORECASE)
        
        expr_match = derivative_pattern.search(expression)
        if not expr_match:
            # Try a different pattern
            expr_match = alternative_pattern.search(expression)
            if expr_match:
                var_name = expr_match.group(2)
                expr_text = expr_match.group(3)
            else:
                raise ValueError("Could not parse derivative expression. Please use format 'derivative of f(x) with respect to x'")
        else:
            expr_text = expr_match.group(2)
            var_name = expr_match.group(4) if expr_match.group(4) else 'x'
        
        # Performance optimization: cache the transformation object
        transformations = standard_transformations + (implicit_multiplication_application,)
        
        # Try to simplify the expression before calculating derivative
        expr = parse_expr(expr_text, transformations=transformations)
        
        # Cache the symbolic variable
        var = symbols(var_name)
        
        # Compute the derivative with error handling
        try:
            derivative = diff(expr, var)
            
            steps.append(f"Starting with expression: {expr}")
            steps.append(f"Taking the derivative with respect to {var_name}")
            steps.append("Using the power rule, product rule, chain rule as needed")
            steps.append(f"The derivative is: {derivative}")
            
            # Optimize: Only simplify complex results
            if len(str(derivative)) > 30:
                simplified = simplify(derivative)
                if str(simplified) != str(derivative):
                    steps.append(f"Simplifying: {simplified}")
            else:
                simplified = derivative
            
            return {
                'success': True,
                'steps': steps,
                'result': str(simplified),
                'id': str(uuid.uuid4())
            }
        except Exception as diff_error:
            # Try alternative differentiation approach for special functions
            try:
                steps.append(f"Standard differentiation failed, trying alternative method: {str(diff_error)}")
                # For rational functions, try a different approach
                if '/' in expr_text:
                    parts = expr_text.split('/')
                    if len(parts) == 2:
                        num = parse_expr(parts[0], transformations=transformations)
                        denom = parse_expr(parts[1], transformations=transformations)
                        
                        # Apply quotient rule: (f/g)' = (f'g - fg')/g²
                        num_deriv = diff(num, var)
                        denom_deriv = diff(denom, var)
                        
                        result = (num_deriv * denom - num * denom_deriv) / (denom**2)
                        steps.append(f"Using quotient rule: (f/g)' = (f'g - fg')/g²")
                        steps.append(f"Result: {result}")
                        
                        simplified = simplify(result)
                        return {
                            'success': True,
                            'steps': steps,
                            'result': str(simplified),
                            'id': str(uuid.uuid4())
                        }
                
                # If we got here, we couldn't use alternative approaches either
                raise diff_error
            except Exception:
                raise
    except Exception as e:
        return {
            'success': False,
            'error': f"Error computing derivative: {str(e)}"
        }

def compute_integral(expression):
    """Compute the integral of an expression"""
    try:
        steps = []
        
        # Performance optimization: use pre-compiled regex patterns
        integral_pattern = re.compile(r'(integral|integrate)\s+of\s+(.+?)(\s+with\s+respect\s+to\s+(.+))?$', re.IGNORECASE)
        alt_pattern = re.compile(r'∫\s*(.+?)\s*d([a-z])', re.IGNORECASE)
        
        expr_match = integral_pattern.search(expression)
        if not expr_match:
            # Try a different pattern
            expr_match = alt_pattern.search(expression)
            if expr_match:
                expr_text = expr_match.group(1)
                var_name = expr_match.group(2)
            else:
                raise ValueError("Could not parse integral expression. Please use format 'integral of f(x) with respect to x'")
        else:
            expr_text = expr_match.group(2)
            var_name = expr_match.group(4) if expr_match.group(4) else 'x'
        
        # Make sure to replace '^' with '**' for proper exponentiation
        expr_text = expr_text.replace('^', '**')
        
        # Cache transformation for better performance
        transformations = standard_transformations + (implicit_multiplication_application,)
        
        # Try to simplify the expression before integration for better performance
        expr = parse_expr(expr_text, transformations=transformations)
        simplified_expr = simplify(expr) if '+' in str(expr) or '*' in str(expr) else expr
        
        # Cache the variable
        var = symbols(var_name)
        
        # Add timeout handling for integration
        try:
            # Try common pattern matching first for better performance
            # Special case: power rule for polynomials x**n
            if var_name in str(expr) and ('**' in str(expr) or '^' in str(expr)) and not any(op in str(expr) for op in ['+', '-', '*', '/', 'sin', 'cos', 'tan', 'log']):
                steps.append("Recognized polynomial integration pattern")
                steps.append("Applying power rule: ∫x^n dx = x^(n+1)/(n+1) + C, where n ≠ -1")
                
            # Special case: exponential functions e^x
            elif 'exp' in str(expr) or 'e**' in str(expr) or 'e^' in str(expr):
                steps.append("Recognized exponential integration pattern")
                steps.append("Applying exponential rule: ∫e^x dx = e^x + C")
                
            # Special case: logarithmic functions 1/x
            elif '1/' + var_name in str(expr) or '1 /' + var_name in str(expr):
                steps.append("Recognized logarithmic integration pattern")
                steps.append("Applying logarithm rule: ∫(1/x) dx = ln|x| + C")
            
            # Compute the integral with timeout handling
            integral = integrate(simplified_expr, var)
            
            steps.append(f"Starting with expression: {expr}")
            steps.append(f"Taking the indefinite integral with respect to {var_name}")
            steps.append("Using substitution, integration by parts, or other techniques as needed")
            steps.append(f"The indefinite integral is: {integral} + C")
            
            return {
                'success': True,
                'steps': steps,
                'result': f"{integral} + C",
                'id': str(uuid.uuid4())
            }
        except Exception as int_error:
            steps.append(f"Standard integration method failed: {str(int_error)}")
            steps.append("Attempting alternative integration method...")
            
            # Try alternative integration methods
            try:
                # Try integration by parts for products
                if '*' in str(expr):
                    steps.append("Using integration by parts technique")
                    # Use a more robust integration method or a numerical approach
                    from sympy import apart, together
                    
                    # Try partial fractions for rational functions
                    if '/' in str(expr):
                        steps.append("Applying partial fraction decomposition")
                        decomposed = apart(expr, var)
                        if str(decomposed) != str(expr):
                            steps.append(f"Decomposed expression: {decomposed}")
                            integral = integrate(decomposed, var)
                            steps.append(f"The indefinite integral is: {integral} + C")
                            return {
                                'success': True,
                                'steps': steps,
                                'result': f"{integral} + C",
                                'id': str(uuid.uuid4())
                            }
                    
                    # Fall back to numerical integration for complex functions
                    steps.append("Expression too complex for symbolic integration, approximating result")
                    # This would be an approximation
                    return {
                        'success': True,
                        'steps': steps,
                        'result': f"Integral of {expr} with respect to {var_name} (approximation needed) + C",
                        'id': str(uuid.uuid4())
                    }
                
                # If we reached here, we have no method that works
                raise ValueError("Could not compute the integral. The expression may be too complex.")
                
            except Exception:
                raise
    except Exception as e:
        return {
            'success': False,
            'error': f"Error computing integral: {str(e)}"
        }

def factorize_expression(expression):
    """Factorize a mathematical expression"""
    try:
        steps = []
        
        # Extract the actual expression from the directive
        expr_match = re.search(r'factor\s+(.+)$', expression, re.IGNORECASE)
        if not expr_match:
            raise ValueError("Could not parse factorization request. Please use format 'factor expression'")
        
        expr_text = expr_match.group(1)
        
        # Make sure to replace '^' with '**' for proper exponentiation
        expr_text = expr_text.replace('^', '**')
        
        # Parse the expression with implicit multiplication
        transformations = standard_transformations + (implicit_multiplication_application,)
        expr = parse_expr(expr_text, transformations=transformations)
        
        # Factorize the expression
        factorized = factor(expr)
        
        steps.append(f"Starting with expression: {expr}")
        steps.append("Finding common factors")
        steps.append("Applying the difference of squares, perfect square trinomials, or other factoring techniques")
        steps.append(f"The factorized form is: {factorized}")
        
        return {
            'success': True,
            'steps': steps,
            'result': str(factorized),
            'id': str(uuid.uuid4())
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"Error factorizing expression: {str(e)}"
        }

def expand_expression(expression):
    """Expand a mathematical expression"""
    try:
        steps = []
        
        # Extract the actual expression from the directive
        expr_match = re.search(r'expand\s+(.+)$', expression, re.IGNORECASE)
        if not expr_match:
            raise ValueError("Could not parse expansion request. Please use format 'expand expression'")
        
        expr_text = expr_match.group(1)
        
        # Make sure to replace '^' with '**' for proper exponentiation
        expr_text = expr_text.replace('^', '**')
        
        # Parse the expression with implicit multiplication
        transformations = standard_transformations + (implicit_multiplication_application,)
        expr = parse_expr(expr_text, transformations=transformations)
        
        # Expand the expression
        expanded = expand(expr)
        
        steps.append(f"Starting with expression: {expr}")
        steps.append("Applying the distributive property")
        steps.append("Multiplying out all terms")
        steps.append(f"The expanded form is: {expanded}")
        
        return {
            'success': True,
            'steps': steps,
            'result': str(expanded),
            'id': str(uuid.uuid4())
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"Error expanding expression: {str(e)}"
        }

def simplify_expression(expression):
    """Simplify a mathematical expression"""
    try:
        steps = []
        
        # Extract the actual expression from the directive
        expr_match = re.search(r'simplify\s+(.+)$', expression, re.IGNORECASE)
        if not expr_match:
            raise ValueError("Could not parse simplification request. Please use format 'simplify expression'")
        
        expr_text = expr_match.group(1)
        
        # Make sure to replace '^' with '**' for proper exponentiation
        expr_text = expr_text.replace('^', '**')
        
        # Parse the expression with implicit multiplication
        transformations = standard_transformations + (implicit_multiplication_application,)
        expr = parse_expr(expr_text, transformations=transformations)
        
        # Simplify the expression
        simplified = simplify(expr)
        
        steps.append(f"Starting with expression: {expr}")
        steps.append("Combining like terms")
        steps.append("Applying algebraic identities")
        steps.append(f"The simplified form is: {simplified}")
        
        return {
            'success': True,
            'steps': steps,
            'result': str(simplified),
            'id': str(uuid.uuid4())
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"Error simplifying expression: {str(e)}"
        }

def evaluate_expression(expression):
    """Evaluate a mathematical expression"""
    try:
        steps = []
        
        # Make sure to replace '^' with '**' for proper exponentiation
        expression = expression.replace('^', '**')
        
        # Parse the expression with implicit multiplication
        transformations = standard_transformations + (implicit_multiplication_application,)
        expr = parse_expr(expression, transformations=transformations)
        
        # Check if the expression contains variables
        free_symbols = expr.free_symbols
        if free_symbols:
            # This is a symbolic expression, not a direct calculation
            steps.append(f"The expression {expr} contains variables: {', '.join(str(s) for s in free_symbols)}")
            steps.append("Simplifying the expression")
            simplified = simplify(expr)
            steps.append(f"Simplified form: {simplified}")
            result = str(simplified)
        else:
            # This is a numerical calculation
            steps.append(f"Evaluating the expression: {expr}")
            numeric_result = float(expr.evalf())
            steps.append(f"Result: {numeric_result}")
            result = numeric_result
        
        return {
            'success': True,
            'steps': steps,
            'result': result,
            'id': str(uuid.uuid4())
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"Error evaluating expression: {str(e)}"
        }

def visualize_expression(expression, viz_type='default'):
    """
    Generate visualization data for a mathematical expression.
    Returns data that can be used with Chart.js or other visualization libraries.
    """
    try:
        # Make sure to replace '^' with '**' for proper exponentiation
        expression = expression.replace('^', '**')
        
        # Parse the expression
        transformations = standard_transformations + (implicit_multiplication_application,)
        expr = parse_expr(expression, transformations=transformations)
        
        # Check free symbols to determine variables
        free_symbols = expr.free_symbols
        if not free_symbols:
            return {
                'type': 'text',
                'message': 'No variables to plot. This is a constant value.'
            }
        
        # For simplicity, we'll plot in terms of the first variable found
        var = list(free_symbols)[0]
        var_name = str(var)
        
        # Generate points for plotting
        if viz_type == 'function':
            # Generate a function plot (y = f(x))
            x_values = np.linspace(-10, 10, 100)
            y_values = []
            
            for x_val in x_values:
                try:
                    y_val = float(expr.subs(var, x_val).evalf())
                    if abs(y_val) < 1000:  # Filter out overflow values
                        y_values.append(y_val)
                    else:
                        y_values.append(None)  # Will create a break in the graph
                except:
                    y_values.append(None)
            
            # Create data for Chart.js
            chart_data = {
                'type': 'line',
                'data': {
                    'labels': [round(float(x), 2) for x in x_values],
                    'datasets': [
                        {
                            'label': f'f({var_name})',
                            'data': y_values,
                            'borderColor': 'rgb(75, 192, 192)',
                            'tension': 0.1
                        }
                    ]
                },
                'options': {
                    'responsive': True,
                    'title': {
                        'display': True,
                        'text': f'Graph of {expression}'
                    },
                    'scales': {
                        'x': {
                            'title': {
                                'display': True,
                                'text': var_name
                            }
                        },
                        'y': {
                            'title': {
                                'display': True,
                                'text': f'f({var_name})'
                            }
                        }
                    }
                }
            }
            
            return chart_data
        
        elif viz_type == '3d':
            # For multiple variables, create a 3D surface plot
            if len(free_symbols) >= 2:
                var1, var2 = list(free_symbols)[:2]
                var1_name = str(var1)
                var2_name = str(var2)
                
                # Generate grid for 3D plot
                x_vals = np.linspace(-5, 5, 20)
                y_vals = np.linspace(-5, 5, 20)
                
                z_vals = []
                for y in y_vals:
                    row = []
                    for x in x_vals:
                        try:
                            z = float(expr.subs({var1: x, var2: y}).evalf())
                            if abs(z) < 1000:  # Filter out overflow values
                                row.append(z)
                            else:
                                row.append(None)
                        except:
                            row.append(None)
                    z_vals.append(row)
                
                # Create data for a 3D surface plot
                # This would need to be rendered with a 3D plotting library on the frontend
                chart_data = {
                    'type': '3d_surface',
                    'data': {
                        'x': [round(float(x), 2) for x in x_vals],
                        'y': [round(float(y), 2) for y in y_vals],
                        'z': z_vals
                    },
                    'options': {
                        'title': f'3D surface plot of {expression}',
                        'xLabel': var1_name,
                        'yLabel': var2_name,
                        'zLabel': f'f({var1_name}, {var2_name})'
                    }
                }
                
                return chart_data
            else:
                # Fall back to 2D plot if there's only one variable
                return visualize_expression(expression, 'function')
        
        else:
            # Default visualization based on expression type
            if isinstance(expr, sp.Eq):
                # For equations, plot both sides
                lhs = expr.lhs
                rhs = expr.rhs
                
                x_values = np.linspace(-10, 10, 100)
                lhs_values = []
                rhs_values = []
                
                for x_val in x_values:
                    try:
                        lhs_val = float(lhs.subs(var, x_val).evalf())
                        rhs_val = float(rhs.subs(var, x_val).evalf())
                        
                        if abs(lhs_val) < 1000 and abs(rhs_val) < 1000:
                            lhs_values.append(lhs_val)
                            rhs_values.append(rhs_val)
                        else:
                            lhs_values.append(None)
                            rhs_values.append(None)
                    except:
                        lhs_values.append(None)
                        rhs_values.append(None)
                
                chart_data = {
                    'type': 'line',
                    'data': {
                        'labels': [round(float(x), 2) for x in x_values],
                        'datasets': [
                            {
                                'label': str(lhs),
                                'data': lhs_values,
                                'borderColor': 'rgb(75, 192, 192)',
                                'tension': 0.1
                            },
                            {
                                'label': str(rhs),
                                'data': rhs_values,
                                'borderColor': 'rgb(255, 99, 132)',
                                'tension': 0.1
                            }
                        ]
                    },
                    'options': {
                        'responsive': True,
                        'title': {
                            'display': True,
                            'text': f'Graph of {expression}'
                        },
                        'scales': {
                            'x': {
                                'title': {
                                    'display': True,
                                    'text': var_name
                                }
                            },
                            'y': {
                                'title': {
                                    'display': True,
                                    'text': 'y'
                                }
                            }
                        }
                    }
                }
                
                return chart_data
            else:
                # For regular expressions, create a function plot
                return visualize_expression(expression, 'function')
        
    except Exception as e:
        return {
            'type': 'error',
            'message': f"Error generating visualization: {str(e)}"
        }

def find_variables(expression):
    """Find all variables in an expression"""
    # Find all alphabetic characters that might be variables
    # Excluding known function names
    excluded = ['sin', 'cos', 'tan', 'log', 'exp', 'sqrt', 'abs', 'pi', 'e', 
                'factor', 'expand', 'simplify', 'derivative', 'diff', 'integral', 
                'integrate', 'respect', 'with', 'to', 'of']
    possible_vars = re.findall(r'\b([a-zA-Z]+)\b', expression)
    
    # Filter out known function names
    variables = [var for var in possible_vars if var.lower() not in excluded]
    
    return variables
