import os
import json
from openai import OpenAI

# Get the OpenAI API key 
OPENAI_API_KEY = "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"

# Initialize the OpenAI client
client = OpenAI(api_key=OPENAI_API_KEY)

def generate_explanation(expression, result=None, detail_level='intermediate'):
    """
    Generate an AI-powered explanation of a mathematical expression or concept.
    
    Args:
        expression: The mathematical expression or concept to explain
        result: Optional result of the calculation
        detail_level: Level of detail for explanation (basic, intermediate, advanced)
        
    Returns:
        A detailed explanation from the OpenAI API
    """
    try:
        # Prepare the prompt based on what we're explaining
        if result:
            # We're explaining a specific calculation
            prompt = f"""Explain the following mathematical expression step by step: {expression}
            
            The final result is: {result}
            
            Please provide a {detail_level}-level explanation that:
            1. Breaks down each step of solving this
            2. Explains the mathematical concepts involved
            3. Uses clear, concise language
            4. Includes any relevant formulas or rules used
            
            Make the explanation educational and helpful for someone learning this concept.
            """
        else:
            # We're explaining a general mathematical concept
            prompt = f"""Explain the following mathematical concept in detail: {expression}
            
            Please provide a {detail_level}-level explanation that:
            1. Defines the concept clearly
            2. Explains its importance and applications
            3. Provides examples to illustrate the concept
            4. Includes relevant formulas or properties
            5. Connects it to related mathematical ideas
            
            Make the explanation educational and helpful for someone learning this concept.
            """
        
        # Using gpt-4o-mini model as requested by the user
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are MathLens AI, an expert mathematics educator. You provide clear, accurate explanations of mathematical concepts and step-by-step solutions to problems. Your explanations are educational, precise, and easy to understand."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800,
            temperature=0.2
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Error generating explanation: {str(e)}"

def process_natural_language(query):
    """
    Process a natural language math query using OpenAI.
    
    Args:
        query: The natural language query about mathematics
        
    Returns:
        Processed result with steps, solution, and explanation
    """
    try:
        # Prepare system prompt that instructs the model to analyze math problems
        system_prompt = """You are MathLens AI, an expert mathematics solver and educator. 
        Analyze the given mathematical problem expressed in natural language.
        
        First, identify the type of mathematical problem (algebra, calculus, geometry, etc.).
        Then, translate it into mathematical notation.
        Finally, solve it step by step showing all work clearly.
        
        Format your response as JSON with these fields:
        - problem_type: The category of math problem
        - mathematical_representation: The problem expressed in proper notation
        - steps: Array of step-by-step solution steps
        - result: The final answer
        - explanation: A clear explanation of the approach and concepts
        
        Ensure all mathematical notation is clear and properly formatted.
        """
        
        # Using gpt-4o-mini model as requested by the user
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query}
            ],
            response_format={"type": "json_object"},
            max_tokens=1200,
            temperature=0.2
        )
        
        # Parse the JSON response
        result_json = json.loads(response.choices[0].message.content)
        
        # Format the result for the frontend
        formatted_result = {
            'success': True,
            'original_query': query,
            'problem_type': result_json.get('problem_type', ''),
            'mathematical_form': result_json.get('mathematical_representation', ''),
            'steps': result_json.get('steps', []),
            'result': result_json.get('result', ''),
            'explanation': result_json.get('explanation', '')
        }
        
        return formatted_result
    except Exception as e:
        return {
            'success': False,
            'error': f"Error processing natural language query: {str(e)}"
        }

def generate_visualization_explanation(expression, viz_type):
    """
    Generate an explanation of what a visualization represents.
    
    Args:
        expression: The mathematical expression being visualized
        viz_type: The type of visualization
        
    Returns:
        An explanation of what the visualization shows
    """
    try:
        prompt = f"""Explain what this visualization of {expression} represents and 
        how to interpret it. The visualization type is {viz_type}.
        
        Please explain:
        1. What the graph/visualization shows mathematically
        2. Key features to observe (intercepts, asymptotes, minima/maxima, etc.)
        3. How changes in variables affect the visualization
        4. Real-world interpretations if applicable
        
        Keep the explanation concise but informative.
        """
        
        # Using gpt-4o-mini model as requested by the user
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are MathLens AI, an expert in mathematical visualization. You provide clear, accurate explanations of mathematical visualizations, helping users understand what graphs and plots represent."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=400,
            temperature=0.2
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Error generating visualization explanation: {str(e)}"