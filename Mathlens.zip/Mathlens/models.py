
from datetime import datetime
import uuid
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base, engine_options={
    "pool_size": 10,
    "pool_recycle": 300,
    "pool_pre_ping": True
})

class Feedback(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    rating = db.Column(db.Integer, nullable=False)
    feedback_text = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'), nullable=True)
    email_sent = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Feedback {self.id}: {self.rating}/5>'

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    last_login = db.Column(db.DateTime)
    calculations = db.relationship('Calculation', backref='user', lazy='dynamic')
    practice_sessions = db.relationship('PracticeSession', backref='user', lazy='dynamic')
    feedback = db.relationship('Feedback', backref='user', lazy='dynamic')
    
    # Flask-Login integration
    def is_authenticated(self):
        return True
        
    def is_active(self):
        return self.is_active
        
    def is_anonymous(self):
        return False
        
    def get_id(self):
        return str(self.id)

class Calculation(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    expression = db.Column(db.String(500), nullable=False)
    result = db.Column(db.Text)
    steps = db.Column(db.Text)  # Store JSON string of steps
    explanation = db.Column(db.Text)
    category = db.Column(db.String(50))
    status = db.Column(db.String(20), default='completed')  # 'completed', 'rejected', 'processing'
    error_message = db.Column(db.Text)  # Store error message if status is 'rejected'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    
    def __repr__(self):
        return f'<Calculation {self.expression}>'

class Visualization(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    calculation_id = db.Column(db.String(36), db.ForeignKey('calculation.id', ondelete='CASCADE'))
    visualization_type = db.Column(db.String(50))
    data = db.Column(db.Text)  # Store JSON string of visualization data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    calculation = db.relationship('Calculation', backref='visualizations')

class PracticeProblem(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    problem_text = db.Column(db.Text, nullable=False)
    answer = db.Column(db.Text, nullable=False)
    explanation = db.Column(db.Text)
    hints = db.Column(db.Text)  # Stored as JSON string
    category = db.Column(db.String(50))
    difficulty = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<PracticeProblem {self.id}>'

class PracticeSession(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    category = db.Column(db.String(50))
    difficulty = db.Column(db.String(20))
    score = db.Column(db.Integer, default=0)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    completed = db.Column(db.Boolean, default=False)
    
    attempts = db.relationship('PracticeAttempt', backref='session', lazy='dynamic')
    
    def __repr__(self):
        return f'<PracticeSession {self.id}>'

class PracticeAttempt(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = db.Column(db.String(36), db.ForeignKey('practice_session.id', ondelete='CASCADE'))
    problem_id = db.Column(db.String(36), db.ForeignKey('practice_problem.id', ondelete='CASCADE'))
    user_answer = db.Column(db.Text)
    is_correct = db.Column(db.Boolean, default=False)
    hints_used = db.Column(db.Integer, default=0)
    time_spent = db.Column(db.Integer)  # Time spent in seconds
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<PracticeAttempt {self.id}>'

class ChatMessage(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_deleted = db.Column(db.Boolean, default=False)
    
    user = db.relationship('User', backref='chat_messages')

class UserWarning(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'))
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='SET NULL'))
    reason = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    warning_type = db.Column(db.String(20))  # 'warning' or 'ban'
    expires_at = db.Column(db.DateTime, nullable=True)
    
    user = db.relationship('User', foreign_keys=[user_id], backref='warnings')
    admin = db.relationship('User', foreign_keys=[admin_id])
