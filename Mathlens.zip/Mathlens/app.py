import os
import logging
import json
import time
import uuid
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_compress import Compress
from flask_socketio import SocketIO, emit
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from utils.math_processor import process_expression, visualize_expression
from utils.openai_helper import generate_explanation, process_natural_language
from openai import OpenAI
from models import db, ChatMessage, UserWarning, User, PracticeProblem, PracticeSession, Calculation

# Initialize OpenAI client with the API key
api_key = os.environ.get("OPENAI_API_KEY", "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")
client = OpenAI(api_key=api_key)

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
Compress(app)
app.secret_key = os.environ.get("SESSION_SECRET", "mathlens-dev-key")
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 31536000  # Cache static files for 1 year
app.config['SQLALCHEMY_ECHO'] = False  # Disable SQL query logging

# Configure database
database_url = os.environ.get("DATABASE_URL")
if database_url:
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
else:
    logging.warning("DATABASE_URL environment variable not set. Using SQLite as fallback.")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///mathlens.db"

# Initialize database
db.init_app(app)

# Initialize SocketIO
socketio = SocketIO(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Create all database tables
with app.app_context():
    db.create_all()
    logging.info("Database tables created")

    # Add initial practice problems if none exist
    if not PracticeProblem.query.first():
        initial_problems = [
            {
                'problem_text': 'Solve for x: 2x + 3 = 7',
                'answer': '2',
                'explanation': 'Subtract 3 from both sides: 2x = 4\nDivide both sides by 2: x = 2',
                'hints': json.dumps(['Start by isolating x on one side', 'Subtract 3 from both sides', 'Divide both sides by 2']),
                'category': 'algebra',
                'difficulty': 'easy'
            },
            {
                'problem_text': 'Find the derivative of f(x) = x² + 3x',
                'answer': '2x + 3',
                'explanation': 'Using power rule for x²: 2x\nFor 3x: 3\nCombining terms: 2x + 3',
                'hints': json.dumps(['Use the power rule', 'The derivative of x² is 2x', 'Don\'t forget the constant term']),
                'category': 'calculus',
                'difficulty': 'medium'
            },
            {
                'problem_text': 'Calculate the area of a circle with radius 5',
                'answer': '78.54',
                'explanation': 'Area = πr²\nArea = π × 5²\nArea = π × 25 ≈ 78.54',
                'hints': json.dumps(['Use the formula for circle area', 'The formula is πr²', 'Plug in r = 5']),
                'category': 'geometry',
                'difficulty': 'easy'
            }
        ]

        for problem_data in initial_problems:
            problem = PracticeProblem(**problem_data)
            db.session.add(problem)

        db.session.commit()
        logging.info("Added initial practice problems")

@app.route('/')
def home():
    """Render the main calculator page"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login"""
    if current_user.is_authenticated:
        return redirect(url_for('home'))
        
    if request.method == 'POST':
        data = request.form
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            flash('Please provide both username and password', 'error')
            return render_template('login.html')
            
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            next_page = request.args.get('next')
            if not next_page or not next_page.startswith('/'):
                next_page = url_for('home')
                
            return redirect(next_page)
        else:
            flash('Invalid username or password', 'error')
            
    return render_template('login.html')
    
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Handle user registration"""
    if current_user.is_authenticated:
        return redirect(url_for('home'))
        
    if request.method == 'POST':
        data = request.form
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        password_confirm = data.get('password_confirm')
        
        if not all([username, email, password, password_confirm]):
            flash('All fields are required', 'error')
            return render_template('register.html')
            
        if password != password_confirm:
            flash('Passwords must match', 'error')
            return render_template('register.html')
            
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
            
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('register.html')
            
        # Create new user
        new_user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password)
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! You can now log in', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')
    
@app.route('/logout')
@login_required
def logout():
    """Handle user logout"""
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('home'))

@app.route('/camera')
def camera():
    """Render the camera page for photo-based math problem solving"""
    return render_template('camera.html')

@app.route('/camera/process', methods=['POST'])
def process_camera_image():
    """Process a camera image to extract and solve mathematical expressions"""
    try:
        data = request.get_json()
        base64_image = data.get('image', '')

        if not base64_image:
            return jsonify({'success': False, 'error': 'No image provided'})

        # In a full implementation, we would send the image to an OCR service
        # or use a local library like pytesseract to extract text from the image.
        # For this prototype, we'll simulate OCR by returning a sample expression:

        # For demo purposes, simulate detecting an expression from the image
        detected_expression = "2x + 3 = 7"

        # Process the detected expression
        result = process_expression(detected_expression)

        return jsonify({
            'success': True,
            'expression': detected_expression,
            'result': result
        })
    except Exception as e:
        logging.error(f"Error processing camera image: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/solve', methods=['POST'])
def solve():
    """Process and solve mathematical expressions"""
    try:
        data = request.get_json()
        expression = data.get('expression', '')
        
        # Create a new calculation record if user is logged in
        calculation = None
        if current_user.is_authenticated:
            calculation = Calculation(
                expression=expression,
                user_id=current_user.id,
                status='processing'
            )
            db.session.add(calculation)
            db.session.commit()

        # Check if the expression is in natural language
        if not any(char in expression for char in '+-*/^()=<>'):
            # This appears to be natural language, process it
            try:
                result = process_natural_language(expression)
                
                # Update calculation if exists
                if calculation:
                    calculation.result = json.dumps(result.get('result', ''))
                    calculation.steps = json.dumps(result.get('steps', []))
                    calculation.explanation = result.get('explanation', '')
                    calculation.status = 'completed'
                    db.session.commit()
                
                return jsonify(result)
            except Exception as e:
                # Mark as rejected
                if calculation:
                    calculation.status = 'rejected'
                    calculation.error_message = str(e)
                    db.session.commit()
                raise

        # Process as a mathematical expression
        try:
            result = process_expression(expression)
            
            # Get AI-powered explanation if requested
            if data.get('explain', False):
                explanation = generate_explanation(expression, result)
                result['explanation'] = explanation
                
                # Store explanation if calculation exists
                if calculation:
                    calculation.explanation = explanation
            
            # Update calculation if exists
            if calculation:
                calculation.result = json.dumps(result.get('result', ''))
                calculation.steps = json.dumps(result.get('steps', []))
                calculation.status = 'completed'
                db.session.commit()
                
            return jsonify(result)
        except Exception as e:
            # Mark as rejected
            if calculation:
                calculation.status = 'rejected'
                calculation.error_message = str(e)
                db.session.commit()
            raise
    except Exception as e:
        logging.error(f"Error solving expression: {str(e)}")
        return jsonify({
            'success': False, 
            'error': str(e),
            'status': 'rejected'
        })

@app.route('/visualize', methods=['POST'])
def visualize():
    """Generate visualizations for mathematical expressions"""
    try:
        data = request.get_json()
        expression = data.get('expression', '')
        viz_type = data.get('type', 'default')

        visualization_data = visualize_expression(expression, viz_type)
        return jsonify({'success': True, 'visualization': visualization_data})
    except Exception as e:
        logging.error(f"Error visualizing expression: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/explain', methods=['POST'])
def explain():
    """Generate AI-powered explanations for mathematical concepts"""
    try:
        data = request.get_json()
        concept = data.get('concept', '')
        detail_level = data.get('level', 'intermediate')

        explanation = generate_explanation(concept, None, detail_level)
        return jsonify({'success': True, 'explanation': explanation})
    except Exception as e:
        logging.error(f"Error generating explanation: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/history', methods=['GET'])
def get_history():
    """Retrieve calculation history from the session"""
    history = session.get('history', [])
    return jsonify({'success': True, 'history': history})

@app.route('/history', methods=['GET'])
def math_history():
    """Display the history of mathematics page"""
    return render_template('history.html')

@app.route('/mathgpt')
def mathgpt():
    """Render the Math GPT chat interface"""
    return render_template('mathgpt.html')

@app.route('/feedback', methods=['GET', 'POST'])
def submit_feedback():
    if request.method == 'GET':
        # Display the feedback form
        return render_template('feedback.html')
    
    # Handle POST request for submitting feedback
    try:
        data = request.get_json()
        feedback_text = data.get('feedback', '')
        rating = data.get('rating', 0)
        
        # First, store the feedback in the database
        user_id = None
        if current_user.is_authenticated:
            user_id = current_user.id
        
        # Create a new Feedback record
        feedback = models.Feedback(
            feedback_text=feedback_text,
            rating=rating,
            user_id=user_id,
            email_sent=False  # Default to not sent
        )
        
        db.session.add(feedback)
        db.session.commit()
        
        logging.info(f"Feedback saved to database with ID: {feedback.id}")
        
        # After saving to DB, attempt to send email with SendGrid
        email_success = False
        email_error_message = None
        
        try:
            # Prepare email content
            email_content = f"""
            New Feedback Received:
            Rating: {rating}/5
            Feedback: {feedback_text}
            """
            
            # Use SendGrid to send the email
            import os
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail
            
            # Sender and receiver
            sender_email = "mathlens.feedback@example.com"
            receiver_email = "rakanawad475@gmail.com"
            
            # Create the email message
            message = Mail(
                from_email=sender_email,
                to_emails=receiver_email,
                subject=f"MathLens Feedback - Rating: {rating}/5",
                plain_text_content=email_content
            )
            
            # Send the email using SendGrid
            sendgrid_client = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
            response = sendgrid_client.send(message)
            
            if response.status_code >= 200 and response.status_code < 300:
                logging.info(f"Email sent with status code: {response.status_code}")
                email_success = True
                
                # Update the feedback record to mark email as sent
                feedback.email_sent = True
                db.session.commit()
        except Exception as email_error:
            email_error_message = str(email_error)
            logging.error(f"SendGrid error: {email_error_message}")
            
        # Return success even if email fails, since we've saved to database
        return jsonify({
            'success': True, 
            'message': 'Feedback submitted successfully',
            'email_sent': email_success,
            'feedback_id': feedback.id
        })
            
    except Exception as e:
        logging.error(f"Error processing feedback: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/test-login', methods=['GET'])
def test_login():
    user_id = request.headers.get('X-Replit-User-Id')
    user_name = request.headers.get('X-Replit-User-Name')
    
    if user_id and user_name:
        return jsonify({
            'success': True,
            'user': {
                'id': user_id,
                'username': user_name
            }
        })
    return jsonify({'success': False, 'error': 'Not logged in'})

@app.route('/mathgpt/chat', methods=['POST']) 
def mathgpt_chat():
    """Process chat messages and return AI responses"""
    try:
        data = request.get_json()
        message = data.get('message', '')

        if not message:
            return jsonify({'success': False, 'error': 'No message provided'})

        # Use the OpenAI client to generate a response
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are Math GPT, an AI math tutor. You are knowledgeable about mathematics and can help explain mathematical concepts, solve problems, and provide step-by-step solutions. Keep your responses focused on mathematics and education."},
                {"role": "user", "content": message}
            ],
            max_tokens=500,
            temperature=0.7
        )

        return jsonify({
            'success': True,
            'response': response.choices[0].message.content
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/export', methods=['POST'])
def export_solution():
    """Export a solution for sharing"""
    try:
        data = request.get_json()
        solution_id = data.get('id')
        format_type = data.get('format', 'text')

        # Get the solution from history
        history = session.get('history', [])
        solution = next((item for item in history if item.get('id') == solution_id), None)

        if not solution:
            return jsonify({'success': False, 'error': 'Solution not found'})

        # Format the solution based on the requested format
        if format_type == 'latex':
            # Convert to LaTeX format
            formatted_solution = {
                'content': "LaTeX formatted content would go here",
                'format': 'latex'
            }
        elif format_type == 'pdf':
            # Generate PDF (mock response for now)
            formatted_solution = {
                'content': "Base64 encoded PDF would go here",
                'format': 'pdf'
            }
        else:
            # Default text format
            formatted_solution = {
                'content': solution,
                'format': 'text'
            }

        return jsonify({'success': True, 'export': formatted_solution})
    except Exception as e:
        logging.error(f"Error exporting solution: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

# Admin Routes
@app.route('/admin/feedback', methods=['GET'])
@login_required
def admin_feedback():
    """View all feedback submissions (admin only)"""
    # Check if the user is an admin
    if not current_user.is_admin:
        flash('You do not have permission to access this page.', 'error')
        return redirect(url_for('home'))
    
    try:
        feedback_items = models.Feedback.query.order_by(models.Feedback.created_at.desc()).all()
        
        feedback_list = []
        for item in feedback_items:
            # Get username if user exists
            username = "Anonymous"
            if item.user_id:
                user = User.query.get(item.user_id)
                if user:
                    username = user.username
            
            feedback_list.append({
                'id': item.id,
                'rating': item.rating,
                'feedback_text': item.feedback_text,
                'username': username,
                'email_sent': item.email_sent,
                'created_at': item.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })
            
        return render_template('admin/feedback.html', feedback=feedback_list)
    except Exception as e:
        logging.error(f"Error fetching feedback: {str(e)}")
        return f"Error: {str(e)}", 500

# Practice Mode Routes
@app.route('/practice', methods=['GET'])
def practice_home():
    """Render the practice mode home page"""
    return render_template('practice.html')

@app.route('/practice/categories', methods=['GET'])
def get_practice_categories():
    """Get available practice categories"""
    categories = [
        {"id": "algebra", "name": "Algebra", "description": "Practice algebraic expressions, equations, and inequalities."},
        {"id": "calculus", "name": "Calculus", "description": "Practice derivatives, integrals, and limits."},
        {"id": "geometry", "name": "Geometry", "description": "Practice geometric problems and proofs."},
        {"id": "trigonometry", "name": "Trigonometry", "description": "Practice trigonometric functions and identities."},
        {"id": "statistics", "name": "Statistics", "description": "Practice statistical concepts and probability."}
    ]
    return jsonify({"success": True, "categories": categories})

@app.route('/practice/problems', methods=['GET', 'POST'])
def get_practice_problems():
    """Get practice problems based on category and difficulty"""
    if request.method == 'POST':
        data = request.get_json()
        category = data.get('category', 'algebra')
        difficulty = data.get('difficulty', 'medium')
    else:
        category = request.args.get('category', 'algebra')
        difficulty = request.args.get('difficulty', 'medium')

    try:
        # Query problems from database
        problems = PracticeProblem.query.filter_by(
            category=category, 
            difficulty=difficulty
        ).all()

        # If no problems found, query without difficulty to get any problems in the category
        if not problems:
            problems = PracticeProblem.query.filter_by(
                category=category
            ).all()

        # Initialize generated_problems to None
        generated_problems = None

        # If no problems in database, generate them
        if not problems:
            # For now, return mock problems
            # In a production app, we would generate these with OpenAI
            generated_problems = generate_practice_problems(category, difficulty, 5)

            # Save generated problems to database
            for problem in generated_problems:
                # Ensure all required fields exist in the problem dict
                if all(k in problem for k in ['problem_text', 'answer', 'explanation', 'hints']):
                    db_problem = PracticeProblem(
                        problem_text=problem['problem_text'],
                        difficulty=difficulty,
                        category=category,
                        answer=problem['answer'],
                        explanation=problem['explanation'],
                        hints=json.dumps(problem['hints']) if isinstance(problem['hints'], list) else json.dumps(["No hints available"])
                    )
                    db.session.add(db_problem)
                else:
                    logging.warning(f"Skipping invalid problem: {problem}")

            try:
                db.session.commit()
                logging.info(f"Successfully saved {len(generated_problems)} problems to database")
            except Exception as db_error:
                db.session.rollback()
                logging.error(f"Error saving problems to database: {str(db_error)}")
                # Continue even if we couldn't save to DB - we'll use the generated problems in memory

            # Fetch the newly created problems from the database
            problems = PracticeProblem.query.filter_by(
                category=category, 
                difficulty=difficulty
            ).limit(10).all()

        # Format database problems for API response
        problem_list = []

        # If we have database problems, use those
        if problems:
            for problem in problems:
                problem_list.append({
                    'id': problem.id,
                    'problem_text': problem.problem_text,
                    'difficulty': problem.difficulty,
                    'category': problem.category,
                    'hints': json.loads(problem.hints) if problem.hints else []
                })
        # If database errors occurred but we generated problems, use those directly
        elif generated_problems:
            logging.info(f"Using {len(generated_problems)} in-memory generated problems")
            for i, problem in enumerate(generated_problems):
                # Generate a temporary ID for frontend use
                temp_id = f"temp_{int(time.time())}_{i}"
                problem_list.append({
                    'id': temp_id,
                    'problem_text': problem.get('problem_text', f"Sample {category} problem ({difficulty})"),
                    'difficulty': difficulty,
                    'category': category,
                    'hints': problem.get('hints', ["No hints available"])
                })

        return jsonify({"success": True, "problems": problem_list})
    except Exception as e:
        logging.error(f"Error getting practice problems: {str(e)}")
        return jsonify({"success": False, "error": str(e)})

@app.route('/practice/submit', methods=['POST'])
def submit_practice_answer():
    """Submit an answer for a practice problem"""
    try:
        data = request.get_json()
        problem_id = data.get('problem_id')
        user_answer = data.get('answer')
        session_id = data.get('session_id')
        time_spent = data.get('time_spent', 0)

        # Check if it's a temporary ID (generated by frontend)
        if problem_id and problem_id.startswith('temp_'):
            # This is a temporary ID - we need to use the current problem from the session
            # For now, just return a canned response
            return jsonify({
                "success": True,
                "is_correct": True,
                "correct_answer": user_answer,
                "explanation": "Good job! Since this is a newly generated problem, we'll count your answer as correct."
            })

        # Get the problem from database
        problem = PracticeProblem.query.get(problem_id)
        if not problem:
            return jsonify({"success": False, "error": "Problem not found"})

        # Check if answer is correct (simple string comparison for now)
        # In a real app, we might need more sophisticated answer checking
        is_correct = check_practice_answer(user_answer, problem.answer)

        # If user is logged in, save their attempt
        if current_user.is_authenticated:
            user_id = current_user.id

            # If no session_id, create a new practice session
            if not session_id:
                practice_session = PracticeSession(
                    user_id=user_id,
                    category=problem.category,
                    difficulty=problem.difficulty
                )
                db.session.add(practice_session)
                db.session.flush()
                session_id = practice_session.id
            else:
                practice_session = PracticeSession.query.get(session_id)

            # Record the attempt
            attempt = models.PracticeAttempt(
                session_id=session_id,
                problem_id=problem_id,
                user_answer=user_answer,
                is_correct=is_correct,
                time_spent=time_spent
            )
            db.session.add(attempt)

            # Update session score if answer is correct
            if is_correct:
                practice_session.score += 1

            db.session.commit()

        # Return the result with explanation if answer was submitted
        if user_answer:
            return jsonify({
                "success": True,
                "is_correct": is_correct,
                "correct_answer": problem.answer,
                "explanation": problem.explanation
            })
        else:
            return jsonify({
                "success": False,
                "error": "No answer provided"
            })
    except Exception as e:
        logging.error(f"Error submitting practice answer: {str(e)}")
        return jsonify({"success": False, "error": str(e)})

@app.route('/practice/hint', methods=['POST'])
def get_practice_hint():
    """Get a hint for a practice problem"""
    try:
        data = request.get_json()
        problem_id = data.get('problem_id')
        hint_index = data.get('hint_index', 0)

        # Check if it's a temporary ID (generated by frontend)
        if problem_id and problem_id.startswith('temp_'):
            # For temporary problems, provide default hints
            generic_hints = [
                "Try breaking down the problem into smaller steps.",
                "Look for patterns in the problem that might help you solve it.",
                "Consider using the relevant mathematical formulas for this type of problem."
            ]

            if hint_index < len(generic_hints):
                return jsonify({
                    "success": True,
                    "hint": generic_hints[hint_index],
                    "has_more_hints": hint_index < len(generic_hints) - 1
                })
            else:
                return jsonify({
                    "success": False,
                    "error": "No more hints available"
                })

        # Regular flow for database-stored problems
        problem = PracticeProblem.query.get(problem_id)
        if not problem:
            return jsonify({"success": False, "error": "Problem not found"})

        hints = json.loads(problem.hints) if problem.hints else []

        if hint_index < len(hints):
            return jsonify({
                "success": True,
                "hint": hints[hint_index],
                "has_more_hints": hint_index < len(hints) - 1
            })
        else:
            return jsonify({
                "success": False,
                "error": "No more hints available"
            })
    except Exception as e:
        logging.error(f"Error getting practice hint: {str(e)}")
        return jsonify({"success": False, "error": str(e)})

def generate_practice_problems(category, difficulty, count=5):
    """Generate practice problems using OpenAI API or return default problems"""
    default_problems = {
        "algebra": [
            {
                "problem_text": "What is the value of x in the equation 4x + 8 = 20?",
                "answer": "3",
                "explanation": "Subtract 8 from both sides: 4x = 12\nDivide both sides by 4: x = 3",
                "hints": ["First isolate the term with x", "Subtract 8 from both sides", "Divide both sides by 4"]
            },
            {
                "problem_text": "Solve for y: 6y - 12 = 30",
                "answer": "7",
                "explanation": "Add 12 to both sides: 6y = 42\nDivide both sides by 6: y = 7",
                "hints": ["Move all numbers to the right side", "Add 12 to both sides", "Divide by 6"]
            },
            {
                "problem_text": "Find the value of z when 2z + 5 = 15",
                "answer": "5",
                "explanation": "Subtract 5 from both sides: 2z = 10\nDivide both sides by 2: z = 5",
                "hints": ["First isolate the term with z", "Subtract 5 from both sides", "Divide by 2"]
            }
        ],
        "calculus": [
            {
                "problem_text": "Find the derivative of f(x) = x² + 3x",
                "answer": "2x + 3",
                "explanation": "Using power rule: derivative of x² is 2x\nDerivative of 3x is 3\nAdd the terms: 2x + 3",
                "hints": ["Use the power rule", "Remember the derivative of x² is 2x", "Don't forget the constant term"]
            },
            {
                "problem_text": "Find the integral of f(x) = 2x",
                "answer": "x² + C",
                "explanation": "To integrate 2x, increase power by 1 and divide by new power\n2x becomes x²\nAdd constant C",
                "hints": ["Reverse the power rule", "Add 1 to the power", "Don't forget +C"]
            }
        ],
        "geometry": [
            {
                "problem_text": "Find the area of a circle with radius 5",
                "answer": "78.54",
                "explanation": "Use the formula A = πr²\nA = π × 5²\nA = π × 25 ≈ 78.54",
                "hints": ["Use the circle area formula", "Square the radius first", "Multiply by π"]
            },
            {
                "problem_text": "Find the volume of a cube with side length 3",
                "answer": "27",
                "explanation": "Use the formula V = s³\nV = 3³\nV = 27",
                "hints": ["Use the cube volume formula", "Cube the sidelength", "Calculate 3 × 3 × 3"]
            }
        ]
    }
    
    try:
        system_prompt = f"""Generate {count} {difficulty} level math problems in the {category} category.
        For each problem, provide:
        1. The problem text
        2. The correct answer
        3. A detailed explanation of how to solve it
        4. Three progressive hints (from subtle to more direct)

        Format your response as a JSON object with a 'problems' field containing an array of objects.
        Each problem object should have these keys:
        "problem_text", "answer", "explanation", "hints" (an array of 3 strings)

        Make the problems appropriate for {difficulty} difficulty in {category}.
        """

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=2000,
            temperature=0.7
        )

        result = json.loads(response.choices[0].message.content)
        problems = result.get('problems', [])
        if problems:
            return problems
        
        # If no problems generated, use defaults
        raise ValueError("No problems found in the OpenAI response")
        
    except Exception as e:
        logging.error(f"Error generating practice problems: {str(e)}")
        # Return default problems based on category
        category_problems = default_problems.get(category.lower(), default_problems["algebra"])
        # Ensure we don't go out of bounds with slicing
        num_problems = len(category_problems)
        if num_problems == 0:
            # If no problems for this category, use algebra as fallback
            category_problems = default_problems["algebra"]
            num_problems = len(category_problems)
            
        # Return requested count of problems (may include duplicates if count > available problems)
        return category_problems[:min(count, num_problems)] * (count // num_problems + 1)

def check_practice_answer(user_answer, correct_answer):
    """Check if the user's answer is correct"""
    # This is a simple implementation - in a real app, we'd need more sophisticated
    # answer checking that handles equivalent mathematical expressions
    try:
        # Clean up both answers (remove whitespace, lowercase)
        user_clean = user_answer.strip().lower()
        correct_clean = correct_answer.strip().lower()

        # Simple string comparison
        if user_clean == correct_clean:
            return True

        # TODO: Add more sophisticated answer checking using sympy
        # For example, checking if expressions are mathematically equivalent

        return False
    except Exception as e:
        logging.error(f"Error checking practice answer: {str(e)}")
        return False

# Initialize database tables
with app.app_context():
    # Import models here to avoid circular import
    import models
    db.create_all()
    logging.info("Database tables created")

@app.route('/chat')
@login_required
def chat():
    """Display chat room"""
    messages = ChatMessage.query.filter_by(is_deleted=False).order_by(ChatMessage.timestamp.desc()).limit(100).all()
    return render_template('chat.html', messages=messages)

@app.route('/api/messages', methods=['POST'])
@login_required
def send_message():
    """Send a new chat message"""
    data = request.get_json()
    content = data.get('message', '').strip()
    
    if not content:
        return jsonify({'success': False, 'error': 'Message cannot be empty'})
        
    message = ChatMessage(user_id=current_user.id, content=content)
    db.session.add(message)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message_id': message.id,
        'username': current_user.username,
        'timestamp': message.timestamp.strftime('%H:%M:%S')
    })

@app.route('/api/messages/<message_id>', methods=['DELETE'])
@login_required
def delete_message(message_id):
    """Delete a chat message (admin only)"""
    if not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 403
        
    message = ChatMessage.query.get_or_404(message_id)
    message.is_deleted = True
    db.session.commit()
    
    return jsonify({'success': True})

@app.route('/api/warnings', methods=['POST'])
@login_required
def issue_warning():
    """Issue a warning to a user (admin only)"""
    if not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 403
        
    data = request.get_json()
    user_id = data.get('user_id')
    reason = data.get('reason', '').strip()
    warning_type = data.get('type', 'warning')
    duration = data.get('duration', 0)  # Duration in minutes for temporary bans
    
    if not user_id or not reason:
        return jsonify({'success': False, 'error': 'Missing required fields'})
        
    warning = UserWarning(
        user_id=user_id,
        admin_id=current_user.id,
        reason=reason,
        warning_type=warning_type
    )
    
    if warning_type == 'ban':
        warning.expires_at = datetime.utcnow() + timedelta(days=7)  # 7-day ban
        
    db.session.add(warning)
    db.session.commit()
    
    return jsonify({'success': True})

@socketio.on('connect')
def handle_connect():
    print('Client connected')

def check_ban_status(user_id):
    """Check if user is banned"""
    warning = UserWarning.query.filter_by(
        user_id=user_id,
        warning_type='ban'
    ).order_by(UserWarning.timestamp.desc()).first()
    
    if warning and (warning.expires_at is None or warning.expires_at > datetime.utcnow()):
        return True, warning
    return False, None

@socketio.on('send_message')
def handle_message(data):
    if not current_user.is_authenticated:
        return
        
    is_banned, ban_info = check_ban_status(current_user.id)
    if is_banned:
        emit('chat_error', {
            'error': 'You are banned from chat',
            'expires_at': ban_info.expires_at.isoformat() if ban_info.expires_at else None
        }, room=request.sid)
        return
    
    # Bot responses based on keywords
    bot_responses = {
        'help': "I can help you with math problems! Just type your question.",
        'hello': "Hello! I'm MathBot, your mathematical assistant.",
        'calculate': "Sure! What would you like to calculate?",
        'explain': "I'll do my best to explain. What topic are you interested in?"
    }
        
    content = data.get('message', '').strip()
    if not content:
        return
        
    message = models.ChatMessage(user_id=current_user.id, content=content)
    db.session.add(message)
    db.session.commit()
    
    emit('new_message', {
        'message_id': message.id,
        'username': current_user.username,
        'content': content,
        'timestamp': message.timestamp.strftime('%H:%M:%S')
    }, broadcast=True)

@socketio.on('delete_message')
def handle_delete(data):
    if not current_user.is_admin:
        return
        
    message_id = data.get('message_id')
    message = models.ChatMessage.query.get(message_id)
    if message:
        message.is_deleted = True
        db.session.commit()
        emit('message_deleted', {'message_id': message_id}, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)