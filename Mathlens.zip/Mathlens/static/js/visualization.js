// Handle visualization rendering
function displayVisualization(vizData) {
    const visualizationContainer = document.getElementById('visualizationContainer');
    const canvas = document.getElementById('visualizationCanvas');
    
    // Check if visualization data is available
    if (!vizData) {
        visualizationContainer.style.display = 'none';
        return;
    }
    
    // Handle different types of visualizations
    if (vizData.type === 'text') {
        // Just display a message, no chart
        visualizationContainer.innerHTML = `<div class="text-center p-4">${vizData.message}</div>`;
        visualizationContainer.style.display = 'block';
        return;
    } else if (vizData.type === 'error') {
        // Hide the container if there's an error
        visualizationContainer.style.display = 'none';
        return;
    } else if (vizData.type === '3d_surface') {
        // We'd need a 3D library like Three.js for this
        // For now, just show a message
        visualizationContainer.innerHTML = `
            <div class="text-center p-4">
                <p>3D visualization available. Click below to view.</p>
                <button class="btn btn-primary btn-sm" onclick="render3DVisualization(${JSON.stringify(vizData)})">
                    View 3D Plot
                </button>
            </div>
        `;
        visualizationContainer.style.display = 'block';
        return;
    }
    
    // For Chart.js visualizations
    if (currentChart) {
        currentChart.destroy();
    }
    
    visualizationContainer.style.display = 'block';
    
    // Create chart based on the visualization type
    if (vizData.type === 'line') {
        currentChart = new Chart(canvas, {
            type: 'line',
            data: vizData.data,
            options: vizData.options
        });
    } else if (vizData.type === 'scatter') {
        currentChart = new Chart(canvas, {
            type: 'scatter',
            data: vizData.data,
            options: vizData.options
        });
    } else if (vizData.type === 'bar') {
        currentChart = new Chart(canvas, {
            type: 'bar',
            data: vizData.data,
            options: vizData.options
        });
    } else {
        // Default to line chart
        currentChart = new Chart(canvas, {
            type: 'line',
            data: vizData.data,
            options: vizData.options
        });
    }
    
    // Add explanation of the visualization if available
    if (vizData.explanation) {
        const explanationDiv = document.createElement('div');
        explanationDiv.classList.add('mt-3', 'p-3', 'bg-light', 'rounded');
        explanationDiv.innerHTML = `
            <h6><i class="fas fa-info-circle me-2"></i>About this Visualization</h6>
            <p>${vizData.explanation}</p>
        `;
        visualizationContainer.appendChild(explanationDiv);
    }
    
    // Request AI explanation of the visualization
    requestVisualizationExplanation();
}

// Request explanation of the visualization from the AI
function requestVisualizationExplanation() {
    const expression = document.getElementById('expression').value;
    
    fetch('/explain', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            concept: `visualization of ${expression}`,
            level: 'intermediate'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.explanation) {
            // Add explanation to the visualization container
            const visualizationContainer = document.getElementById('visualizationContainer');
            
            // Check if explanation div already exists
            let explanationDiv = visualizationContainer.querySelector('.visualization-explanation');
            
            if (!explanationDiv) {
                explanationDiv = document.createElement('div');
                explanationDiv.classList.add('visualization-explanation', 'mt-3', 'p-3', 'bg-light', 'rounded');
                visualizationContainer.appendChild(explanationDiv);
            }
            
            explanationDiv.innerHTML = `
                <h6><i class="fas fa-info-circle me-2"></i>Understanding this Visualization</h6>
                <p>${data.explanation}</p>
            `;
            
            // Apply dark mode if needed
            if (document.body.classList.contains('dark-mode')) {
                explanationDiv.classList.remove('bg-light');
                explanationDiv.classList.add('bg-dark');
            }
        }
    })
    .catch(error => {
        console.error("Error fetching visualization explanation: ", error);
    });
}

// Function to render a 3D visualization (placeholder for future implementation)
function render3DVisualization(vizData) {
    alert("3D visualization feature is under development. Check back soon!");
    
    // This would normally open a modal or new view with Three.js rendering
    // const modal = new bootstrap.Modal(document.getElementById('3dVisualizationModal'));
    // modal.show();
}
