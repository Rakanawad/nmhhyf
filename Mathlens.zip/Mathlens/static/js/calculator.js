// Calculator operations
let calculationHistory = [];
let currentSolutionId = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Load history from localStorage if available
    loadHistoryFromStorage();
});

// Submit the math expression for processing
function submitMath(event) {
    event.preventDefault();
    
    const expressionInput = document.getElementById('expression');
    const expression = expressionInput.value.trim();
    
    if (!expression) {
        showError("Please enter a mathematical expression or question.");
        return;
    }
    
    // Show loading indicator
    showLoading(true);
    
    // Get options
    const explainOption = document.getElementById('explainOption').checked;
    const visualizeOption = document.getElementById('visualizeOption').checked;
    
    // Send to server for processing
    fetch('/solve', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            expression: expression,
            explain: explainOption
        })
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading indicator
        showLoading(false);
        
        if (data.success) {
            // Display the result
            displaySolution(expression, data);
            
            // Add to history
            addToHistory(expression, data);
            
            // If visualization is enabled, request it
            if (visualizeOption) {
                requestVisualization(expression);
            }
        } else {
            showError(data.error || "An error occurred while processing your request.");
        }
    })
    .catch(error => {
        showLoading(false);
        showError("Network error: " + error.message);
    });
}

// Display the solution in the UI
function displaySolution(expression, data) {
    // Store the current solution ID
    currentSolutionId = data.id;
    
    // Update problem title
    const problemTitle = document.getElementById('problemTitle');
    problemTitle.textContent = expression;
    
    // Update solution steps
    const solutionSteps = document.getElementById('solutionSteps');
    solutionSteps.innerHTML = '';
    
    if (data.steps && data.steps.length > 0) {
        data.steps.forEach((step, index) => {
            const stepElement = document.createElement('p');
            stepElement.classList.add('solution-step');
            stepElement.innerHTML = step;
            solutionSteps.appendChild(stepElement);
        });
    } else if (data.original_query) {
        // This is a natural language query
        const stepElement = document.createElement('p');
        stepElement.classList.add('solution-step');
        stepElement.innerHTML = `<strong>Problem Type:</strong> ${data.problem_type}`;
        solutionSteps.appendChild(stepElement);
        
        const mathForm = document.createElement('p');
        mathForm.classList.add('solution-step');
        mathForm.innerHTML = `<strong>Mathematical Form:</strong> ${data.mathematical_form}`;
        solutionSteps.appendChild(mathForm);
        
        // Add each step from the steps array
        if (data.steps && data.steps.length > 0) {
            data.steps.forEach((step, index) => {
                const stepEl = document.createElement('p');
                stepEl.classList.add('solution-step');
                stepEl.innerHTML = step;
                solutionSteps.appendChild(stepEl);
            });
        }
    }
    
    // Update final answer
    const finalAnswer = document.getElementById('finalAnswer');
    if (typeof data.result === 'object' && data.result !== null) {
        finalAnswer.innerHTML = `<strong>Result:</strong> ${JSON.stringify(data.result)}`;
    } else {
        finalAnswer.innerHTML = `<strong>Result:</strong> ${data.result}`;
    }
    
    // Display explanation if available
    const explanationContainer = document.getElementById('explanationContainer');
    const explanationContent = document.getElementById('explanationContent');
    
    if (data.explanation) {
        explanationContent.innerHTML = data.explanation;
        explanationContainer.style.display = 'block';
    } else if (data.original_query && data.explanation) {
        explanationContent.innerHTML = data.explanation;
        explanationContainer.style.display = 'block';
    } else {
        explanationContainer.style.display = 'none';
    }
    
    // Show the result container
    document.getElementById('resultContainer').style.display = 'block';
    
    // Render any mathematical notation
    renderMath();
}

// Request visualization from the server
function requestVisualization(expression) {
    fetch('/visualize', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            expression: expression,
            type: 'default'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayVisualization(data.visualization);
        } else {
            console.log("Visualization not available: " + (data.error || "Unknown error"));
            document.getElementById('visualizationContainer').style.display = 'none';
        }
    })
    .catch(error => {
        console.error("Error fetching visualization: ", error);
        document.getElementById('visualizationContainer').style.display = 'none';
    });
}

// Append character to the expression input
function appendToExpression(value) {
    const expressionInput = document.getElementById('expression');
    expressionInput.value += value;
    expressionInput.focus();
}

// Clear the expression input
function clearExpression() {
    document.getElementById('expression').value = '';
    document.getElementById('expression').focus();
}

// Set an example expression
function setExample(example) {
    document.getElementById('expression').value = example;
    document.getElementById('expression').focus();
}

// Add a calculation to the history
function addToHistory(expression, data) {
    // Create a history entry
    const historyEntry = {
        id: data.id || Date.now().toString(),
        expression: expression,
        result: data.result,
        timestamp: new Date().toISOString()
    };
    
    // Add to the beginning of the array
    calculationHistory.unshift(historyEntry);
    
    // Limit history to 50 items
    if (calculationHistory.length > 50) {
        calculationHistory = calculationHistory.slice(0, 50);
    }
    
    // Save to localStorage
    saveHistoryToStorage();
}

// Load history from localStorage
function loadHistoryFromStorage() {
    const savedHistory = localStorage.getItem('calculationHistory');
    if (savedHistory) {
        try {
            calculationHistory = JSON.parse(savedHistory);
        } catch (e) {
            console.error("Error loading history from storage: ", e);
            calculationHistory = [];
        }
    }
}

// Save history to localStorage
function saveHistoryToStorage() {
    try {
        localStorage.setItem('calculationHistory', JSON.stringify(calculationHistory));
    } catch (e) {
        console.error("Error saving history to storage: ", e);
    }
}

// Load and display history
function loadHistory() {
    const historyList = document.getElementById('historyList');
    const emptyHistory = document.getElementById('emptyHistory');
    
    // Clear current list
    historyList.innerHTML = '';
    
    if (calculationHistory.length === 0) {
        historyList.style.display = 'none';
        emptyHistory.style.display = 'block';
    } else {
        historyList.style.display = 'block';
        emptyHistory.style.display = 'none';
        
        calculationHistory.forEach(entry => {
            const historyItem = document.createElement('div');
            historyItem.classList.add('list-group-item', 'history-item');
            historyItem.onclick = function() {
                document.getElementById('expression').value = entry.expression;
                bootstrap.Modal.getInstance(document.getElementById('historyModal')).hide();
            };
            
            const date = new Date(entry.timestamp);
            const formattedDate = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
            
            historyItem.innerHTML = `
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="history-item-expression">${entry.expression}</div>
                        <small class="text-muted">${formattedDate}</small>
                    </div>
                    <div class="history-item-result">${entry.result}</div>
                </div>
            `;
            
            historyList.appendChild(historyItem);
        });
    }
}

// Clear history
function clearHistory() {
    calculationHistory = [];
    saveHistoryToStorage();
    loadHistory();
}

// Copy the current result to clipboard
function copyResult() {
    const finalAnswer = document.getElementById('finalAnswer');
    const textToCopy = finalAnswer.textContent;
    
    navigator.clipboard.writeText(textToCopy).then(() => {
        showNotification("Result copied to clipboard!");
    }).catch(err => {
        console.error('Could not copy text: ', err);
    });
}

// Export the current solution
function exportSolution() {
    document.getElementById('exportOptions').style.display = 'flex';
}

// Export solution in specific format
function exportAs(format) {
    if (!currentSolutionId) {
        showError("No solution to export");
        return;
    }
    
    fetch('/export', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: currentSolutionId,
            format: format
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (format === 'pdf') {
                // Handle PDF download (would require backend implementation)
                showNotification("PDF export feature coming soon!");
            } else {
                // Copy to clipboard for text and LaTeX
                navigator.clipboard.writeText(data.export.content).then(() => {
                    showNotification(`Solution exported as ${format.toUpperCase()}!`);
                });
            }
        } else {
            showError(data.error || "Export failed");
        }
    })
    .catch(error => {
        showError("Export error: " + error.message);
    });
    
    // Hide export options
    document.getElementById('exportOptions').style.display = 'none';
}

// Show error message
function showError(message) {
    // Create bootstrap alert
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('alert', 'alert-danger', 'alert-dismissible', 'fade', 'show');
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Insert at the top of the page
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 5000);
}

// Show loading indicator
function showLoading(show) {
    // Create or get loading indicator
    let loadingIndicator = document.querySelector('.loading-indicator');
    
    if (!loadingIndicator) {
        loadingIndicator = document.createElement('div');
        loadingIndicator.classList.add('loading-indicator');
        loadingIndicator.innerHTML = `
            <div class="loading-spinner"></div>
            <p>Calculating...</p>
        `;
        document.querySelector('.calculator-container').appendChild(loadingIndicator);
    }
    
    loadingIndicator.style.display = show ? 'block' : 'none';
}

// Show notification
function showNotification(message) {
    // Create notification element if it doesn't exist
    let notification = document.querySelector('.copy-notification');
    
    if (!notification) {
        notification = document.createElement('div');
        notification.classList.add('copy-notification');
        document.body.appendChild(notification);
    }
    
    // Update text and show
    notification.textContent = message;
    notification.classList.add('show');
    
    // Hide after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}
